package edu.ycp.cs201.examplegui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import sun.swing.SwingUtilities2;

public class CounterView extends JPanel {
	private Counter model;
	private CounterController controller;
	
	public CounterView() {
		setPreferredSize(new Dimension(300, 300));
		setBackground(Color.DARK_GRAY);
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				handleMouseClicked(e);
			}
		});
	}
	
	private void handleMouseClicked(MouseEvent e) {
		if (e.getButton() == 1) {
			controller.increaseCount();
		} else if (e.getButton() == 3) {
			controller.decreaseCount();
		}
		repaint();
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		// Paint background
		super.paintComponent(g);
		
		Font f = new Font("dialog", Font.BOLD, 96);
		g.setColor(Color.GREEN);
		g.setFont(f);
		
		String countStr = String.valueOf(model.getCount());
		g.drawString(countStr, 10, 200);
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				Counter model = new Counter();
				CounterController controller = new CounterController();
				controller.setModel(model);
				
				CounterView view = new CounterView();
				view.setModel(model);
				view.setController(controller);
				
				JFrame frame = new JFrame("Counter");
				frame.setContentPane(view);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.pack();
				frame.setVisible(true);
			}
		});
	}

	protected void setController(CounterController controller2) {
		this.controller = controller2;
	}

	protected void setModel(Counter model2) {
		this.model = model2;
	}
}

package edu.ycp.cs201.cards;

public enum Suit {
	// TODO - add suit values
}

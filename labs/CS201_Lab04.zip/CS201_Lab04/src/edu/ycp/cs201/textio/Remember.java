package edu.ycp.cs201.textio;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Remember {
	public static void main(String[] args) throws IOException {
		// TODO: add your code here
	}
}

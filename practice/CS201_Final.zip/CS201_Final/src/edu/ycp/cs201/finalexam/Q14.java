package edu.ycp.cs201.finalexam;

public class Q14 {
	//
	// IMPORTANT: you *must* use recursion.  Do not use a loop.
	//
	public static int maxDigit(int n) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}

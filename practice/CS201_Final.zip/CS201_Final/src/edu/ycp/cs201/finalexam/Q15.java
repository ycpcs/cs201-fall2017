package edu.ycp.cs201.finalexam;

import java.util.Collection;
import java.util.HashSet;
import java.util.TreeSet;

public class Q15 {
	//
	// Don't forget:
	//   - the a and b collections should not be modified:
	//     create a new collection (e.g., list or set), add the results
	//     to it, and return it
	//   - the overall running time should be O(N log N),
	//     where N is the number of elements in collections
	//     a and b
	//
	public static<E extends Comparable<E>>
	Collection<E> notInIntersection(Collection<E> a, Collection<E> b) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}

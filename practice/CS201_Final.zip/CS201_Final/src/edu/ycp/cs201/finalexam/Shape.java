package edu.ycp.cs201.finalexam;

public abstract class Shape implements Comparable<Shape>{
	private String shapeName;
	private double circumference;
	private double area;

	public Shape(String name) {
		shapeName = name;
	}

	public String getShapeName() {
		return shapeName;
	}

	public double getArea() {
		return area;
	}

	public double getCircumference() {
		return circumference;
	}

	// protected so that only sub-classes can access it
	protected void setCircumference(double c) {
		circumference = c;
	}

	// protected so that only sub-classes can access it
	protected void setArea(double a) {
		area = a;
	}

	public abstract double calcCircumference();

	public abstract double calcArea();
}

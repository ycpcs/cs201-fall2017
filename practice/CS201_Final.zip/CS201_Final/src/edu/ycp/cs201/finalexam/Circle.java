package edu.ycp.cs201.finalexam;

// 1) make Circle a subclass of Shape, with a shapeName of "Circle".
// 2) define a radius field (as a double) for Circle, which can only be set through the Circle constructor
// 3) have the Circle constructor use radius and calcCircumference() and calcArea() to set the
//    circumference and area for Shape
// 4) provide a getter method for radius
// 5) have Circle compare Shapes based on area (with a Circle object
//    with the smaller area comparing as less than one with greater area) 

public class Circle { // TODO: make Circle a subclass of Shape
	// TODO: add field(s)

	// TODO: constructor
	
	// TODO: add methods
}

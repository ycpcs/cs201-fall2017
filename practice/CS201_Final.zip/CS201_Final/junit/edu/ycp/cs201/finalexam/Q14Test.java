package edu.ycp.cs201.finalexam;

import static org.junit.Assert.*;

import org.junit.Test;

public class Q14Test {
	@Test
	public void testMaxDigit() throws Exception {
		assertEquals(0, Q14.maxDigit(0));
		assertEquals(4, Q14.maxDigit(4));
		assertEquals(9, Q14.maxDigit(9740882));
		assertEquals(6, Q14.maxDigit(202635));
		assertEquals(6, Q14.maxDigit(46));
		assertEquals(8, Q14.maxDigit(6548));
		assertEquals(9, Q14.maxDigit(27449));
		assertEquals(9, Q14.maxDigit(53939));
		assertEquals(5, Q14.maxDigit(22335));
		assertEquals(7, Q14.maxDigit(7166));
		assertEquals(8, Q14.maxDigit(21586));
		assertEquals(6, Q14.maxDigit(61));
	}
}

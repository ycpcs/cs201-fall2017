package edu.ycp.cs201.finalexam;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class Q15Test {
	private List<Integer> list1;
	private List<Integer> list2;
	private List<String> list3;
	private List<String> list4;
	
	@Before
	public void setUp() {
		list1 = Arrays.asList(1, 2, 3, 4, 5);
		list2 = Arrays.asList(3, 4, 5, 6, 7, 8, 9, 10);
		
		list3 = Arrays.asList(
				"Ardelle",
				"Aline",
				"Taren", // both
				"Beryl",
				"Yesenia", // both
				"Hildegard", // both
				"Alethea",
				"Mohammed" // both
				);
		list4 = Arrays.asList(
				"Jeneva",
				"Ayako",
				"Taren", //both
				"Yesenia", // both
				"Hildegard", // both
				"Daron",
				"Chanda",
				"Xenia",
				"Mohammed" // both
				);
	}
	
	@Test
	public void testNotInIntersectionIntegers() throws Exception {
		Collection<Integer> x = Q15.notInIntersection(list1, list2);
		assertEquals(7, x.size());
		assertTrue(x.contains(1));
		assertTrue(x.contains(2));
		assertTrue(x.contains(6));
		assertTrue(x.contains(7));
		assertTrue(x.contains(8));
		assertTrue(x.contains(9));
		assertTrue(x.contains(10));
	}
	
	@Test
	public void testNotInIntersectionStrings() throws Exception {
		Collection<String> x = Q15.notInIntersection(list3, list4);
		assertEquals(9, x.size());
		assertTrue(x.contains("Ardelle"));
		assertTrue(x.contains("Aline"));
		assertTrue(x.contains("Beryl"));
		assertTrue(x.contains("Alethea"));
		assertTrue(x.contains("Jeneva"));
		assertTrue(x.contains("Ayako"));
		assertTrue(x.contains("Daron"));
		assertTrue(x.contains("Chanda"));
		assertTrue(x.contains("Xenia"));
	}
}

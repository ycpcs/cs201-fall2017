package edu.ycp.cs201.finalexam;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class Q13Test {
	
	private static final double DELTA = 0.001;
	private static final double r1 = 10;
	private static final double r2 = 11;

	private Circle circ1;
	private Circle circ2;

	@Before
	public void setUp() throws Exception {
		circ1 = new Circle(r1);
		circ2 = new Circle(r2);
	}

	@Test
	public void test() {
		assertTrue(circ1.getShapeName().equals("Circle"));
		assertTrue(circ1.getRadius() == r1);
		assertTrue((circ1.getCircumference() > (2 * Math.PI * r1) - DELTA)   &&
		           (circ1.getCircumference() < (2 * Math.PI * r1) + DELTA));
		assertTrue((circ1.getArea() > Math.PI * r1 * r1 - DELTA)   &&
				   (circ1.getArea() < Math.PI * r1 * r1 + DELTA));
		assertTrue((circ1.calcCircumference() > (2 * Math.PI * r1) - DELTA)   &&
		           (circ1.calcCircumference() < (2 * Math.PI * r1) + DELTA));
		assertTrue((circ1.calcArea() > Math.PI * r1 * r1 - DELTA)   &&
				   (circ1.calcArea() < Math.PI * r1 * r1 + DELTA));		
		assertTrue(circ1.compareTo(circ2) < 0);
		assertTrue(circ2.compareTo(circ1) > 0);
		assertTrue(circ1.compareTo(circ1) == 0);
		
	}

}
